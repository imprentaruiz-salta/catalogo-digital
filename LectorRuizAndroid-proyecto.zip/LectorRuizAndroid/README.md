# Lector Ruiz para Android

Proyecto Android Studio inicial para una aplicación nativa de Librería Ruiz. Usa CameraX con `CameraSelector.DEFAULT_BACK_CAMERA` (siempre lente trasero), y ML Kit para leer QR y Code 128; ofrece selector de modo (QR + barras, solo QR o solo barras). Si reconoce un código del catálogo, consulta `https://catalogo-app-zm3w.onrender.com/api/consulta-qr/<codigo>` y muestra nombre, precio y stock.

## Compilación
1. Abrí esta carpeta con Android Studio actualizado (JDK 17, Android SDK 35).
2. Esperá la sincronización de Gradle y ejecutá en un Android físico.
3. O ejecutá `gradle assembleDebug`; el APK queda en `app/build/outputs/apk/debug/app-debug.apk`.
4. En el teléfono, instalá el APK y concedé el permiso Cámara.

Requiere Android 7.0 o posterior y conexión a internet para consultar precios/stock. La cámara necesita permiso del usuario. Código fuente preparado, todavía no compilado ni probado en el teléfono de Carlos.
