package ar.com.impresionesruiz.lector;

import android.Manifest;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.content.Intent;
import android.net.Uri;
import android.graphics.BitmapFactory;
import android.util.Size;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.RadioGroup;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.camera.core.CameraSelector;
import androidx.camera.core.ImageAnalysis;
import androidx.camera.core.ImageProxy;
import androidx.camera.core.Preview;
import androidx.camera.lifecycle.ProcessCameraProvider;
import androidx.camera.view.PreviewView;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import com.google.common.util.concurrent.ListenableFuture;
import com.google.mlkit.vision.barcode.common.Barcode;
import com.google.mlkit.vision.barcode.BarcodeScanner;
import com.google.mlkit.vision.barcode.BarcodeScannerOptions;
import com.google.mlkit.vision.barcode.BarcodeScanning;
import com.google.mlkit.vision.common.InputImage;
import org.json.JSONObject;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicInteger;

public class MainActivity extends AppCompatActivity {
    private static final int CAMERA_REQUEST=41;
    private PreviewView preview;
    private TextView status,result;
    private ImageView productImage;
    private Button openProduct;
    private volatile String productUrl="";
    private RadioGroup modeGroup;
    private ProcessCameraProvider provider;
    private ExecutorService cameraExecutor,lookupExecutor;
    private BarcodeScanner scanner;
    private final AtomicBoolean found=new AtomicBoolean(false);
    private final AtomicInteger generation=new AtomicInteger(0);

    @Override public void onCreate(Bundle saved){super.onCreate(saved);setContentView(R.layout.activity_main);
        preview=findViewById(R.id.preview);status=findViewById(R.id.status);result=findViewById(R.id.result);modeGroup=findViewById(R.id.modeGroup);productImage=findViewById(R.id.productImage);openProduct=findViewById(R.id.openProduct);
        cameraExecutor=Executors.newSingleThreadExecutor();lookupExecutor=Executors.newSingleThreadExecutor();
        findViewById(R.id.start).setOnClickListener(v->{resetResult();startOrAskPermission();});
        findViewById(R.id.stop).setOnClickListener(v->stopCamera());
        findViewById(R.id.retry).setOnClickListener(v->{resetResult();startCamera();});
        openProduct.setOnClickListener(v->{if(!productUrl.isEmpty())startActivity(new Intent(Intent.ACTION_VIEW,Uri.parse(productUrl)));});
        BarcodeScannerOptions options=new BarcodeScannerOptions.Builder().setBarcodeFormats(Barcode.FORMAT_QR_CODE,Barcode.FORMAT_CODE_128).build();
        scanner=BarcodeScanning.getClient(options);
        if(ContextCompat.checkSelfPermission(this,Manifest.permission.CAMERA)==PackageManager.PERMISSION_GRANTED)startCamera();
    }
    private void resetResult(){generation.incrementAndGet();result.setText("");productImage.setImageDrawable(null);productImage.setVisibility(View.GONE);openProduct.setVisibility(View.GONE);productUrl="";preview.setVisibility(View.VISIBLE);found.set(false);}
    private void startOrAskPermission(){if(ContextCompat.checkSelfPermission(this,Manifest.permission.CAMERA)!=PackageManager.PERMISSION_GRANTED){ActivityCompat.requestPermissions(this,new String[]{Manifest.permission.CAMERA},CAMERA_REQUEST);return;}startCamera();}
    @Override public void onRequestPermissionsResult(int request,@NonNull String[] permissions,@NonNull int[] results){super.onRequestPermissionsResult(request,permissions,results);if(request==CAMERA_REQUEST&&results.length>0&&results[0]==PackageManager.PERMISSION_GRANTED)startCamera();else status.setText("Falta permiso de cámara. Permitilo en Ajustes de Android para Lector Ruiz.");}
    private void startCamera(){if(ContextCompat.checkSelfPermission(this,Manifest.permission.CAMERA)!=PackageManager.PERMISSION_GRANTED){startOrAskPermission();return;}found.set(false);status.setText("Abriendo cámara trasera…");ListenableFuture<ProcessCameraProvider> future=ProcessCameraProvider.getInstance(this);future.addListener(()->{try{provider=future.get();Preview p=new Preview.Builder().build();p.setSurfaceProvider(preview.getSurfaceProvider());ImageAnalysis analysis=new ImageAnalysis.Builder().setTargetResolution(new Size(1280,720)).setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST).build();analysis.setAnalyzer(cameraExecutor,this::analyze);provider.unbindAll();provider.bindToLifecycle(this,CameraSelector.DEFAULT_BACK_CAMERA,p,analysis);status.setText("Cámara trasera activa. Enfocá el código completo.");}catch(Exception ex){status.setText("No pude abrir la cámara trasera: "+ex.getMessage());}},ContextCompat.getMainExecutor(this));}
    private void analyze(ImageProxy proxy){android.media.Image image=proxy.getImage();if(image==null||found.get()){proxy.close();return;}InputImage input=InputImage.fromMediaImage(image,proxy.getImageInfo().getRotationDegrees());scanner.process(input).addOnSuccessListener(codes->{for(Barcode code:codes){String raw=code.getRawValue();if(raw==null||raw.trim().isEmpty())continue;boolean qr=code.getFormat()==Barcode.FORMAT_QR_CODE,bar=code.getFormat()==Barcode.FORMAT_CODE_128;int mode=modeGroup.getCheckedRadioButtonId();if(mode==R.id.modeQR&&!qr||mode==R.id.modeBars&&!bar)continue;if(found.compareAndSet(false,true)){runOnUiThread(()->{status.setText((qr?"QR":"Code 128")+" leído.");result.setText("Código: "+raw+"\nConsultando catálogo…");});final int requestGeneration=generation.get();lookupExecutor.execute(()->lookup(raw,requestGeneration));break;}}}).addOnCompleteListener(task->proxy.close());}
    private void lookup(String raw,int requestGeneration){try{String value=raw.trim();if(value.startsWith("http://")||value.startsWith("https://")){java.util.regex.Matcher m=java.util.regex.Pattern.compile("/p/([^/?#]+)").matcher(value);if(m.find())value=java.net.URLDecoder.decode(m.group(1),"UTF-8");}
        String url="https://catalogo-app-zm3w.onrender.com/api/consulta-qr/"+URLEncoder.encode(value,"UTF-8");HttpURLConnection c=(HttpURLConnection)new URL(url).openConnection();c.setConnectTimeout(10000);c.setReadTimeout(15000);c.setRequestMethod("GET");int code=c.getResponseCode();java.io.InputStream stream=code<400?c.getInputStream():c.getErrorStream();java.io.ByteArrayOutputStream out=new java.io.ByteArrayOutputStream();byte[] b=new byte[2048];int n;while((n=stream.read(b))>0)out.write(b,0,n);String text=new String(out.toByteArray(),StandardCharsets.UTF_8);if(code>=400){showResult("Código leído: "+value+"\nNo encontré ficha en el catálogo.",requestGeneration);return;}JSONObject j=new JSONObject(text);String name=j.optString("nombre","Producto"),price=j.optString("price_display",j.optString("precio","Precio no disponible")),stock=j.optString("stock_display",""),productCode=j.optString("codigo",value);String imagePath=j.optString("image",j.optString("foto",""));if(!imagePath.isEmpty()&&!imagePath.startsWith("http://")&&!imagePath.startsWith("https://"))imagePath="https://catalogo-app-zm3w.onrender.com"+(imagePath.startsWith("/")?"":"/")+imagePath;String ficha="https://catalogo-app-zm3w.onrender.com/p/"+URLEncoder.encode(productCode,"UTF-8");showProduct(name+"\n"+price+"\n"+stock+"\nCódigo: "+productCode,imagePath,ficha,requestGeneration);c.disconnect();
        }catch(Exception e){showResult("Código leído: "+raw+"\nNo pude consultar el catálogo. Revisá internet o buscá el código manualmente.",requestGeneration);}}
    private void showResult(String text,int requestGeneration){runOnUiThread(()->{if(generation.get()!=requestGeneration)return;result.setText(text);status.setText("Listo. Tocá «Escanear otro» para continuar.");});}
    private void showProduct(String text,String imageUrl,String fichaUrl,int requestGeneration){runOnUiThread(()->{if(generation.get()!=requestGeneration)return;result.setText(text);status.setText("Producto encontrado en el catálogo.");preview.setVisibility(View.GONE);openProduct.setVisibility(View.VISIBLE);productUrl=fichaUrl;});if(imageUrl!=null&&!imageUrl.isEmpty()){try{HttpURLConnection img=(HttpURLConnection)new URL(imageUrl).openConnection();img.setConnectTimeout(10000);img.setReadTimeout(15000);img.setInstanceFollowRedirects(true);img.setRequestMethod("GET");img.connect();if(img.getResponseCode()<400){final android.graphics.Bitmap bitmap=BitmapFactory.decodeStream(img.getInputStream());if(bitmap!=null)runOnUiThread(()->{if(generation.get()!=requestGeneration)return;productImage.setImageBitmap(bitmap);productImage.setVisibility(View.VISIBLE);});}img.disconnect();}catch(Exception ignored){}}}
    private void stopCamera(){if(provider!=null)provider.unbindAll();status.setText("Cámara detenida.");}
    @Override protected void onDestroy(){super.onDestroy();if(provider!=null)provider.unbindAll();if(scanner!=null)scanner.close();if(cameraExecutor!=null)cameraExecutor.shutdown();if(lookupExecutor!=null)lookupExecutor.shutdown();}
}
