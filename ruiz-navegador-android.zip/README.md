# Ruiz Navegador

Aplicación Android autónoma para abrir los catálogos de Librería Ruiz e Impresiones Ruiz. Integra GeckoView por medio de la dependencia oficial de Mozilla (no abre Chrome ni Firefox y no depende de que estén instalados).

La app usa el paquete `com.zapia.ruizbrowser2026`, para instalarse separada de versiones experimentales previas. Requiere Android 8.0/API 26 o posterior. El build de Gradle mantiene el manifiesto combinado de GeckoView, compresión/extracción de bibliotecas nativas adecuada, y empaqueta las ABI disponibles en el artefacto oficial universal.

El motor web reproduce audio y video HTML5 compatibles con Android; no incluye un sistema universal de extensiones de escritorio. La reproducción y permisos en hardware real deben validarse en el TCL de Carlos.
