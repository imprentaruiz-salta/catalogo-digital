package com.zapia.ruizweb;
import android.app.*;import android.os.*;import android.Manifest;import android.content.*;import android.content.pm.PackageManager;import android.graphics.Color;import android.graphics.Typeface;import android.view.*;import android.view.inputmethod.InputMethodManager;import android.content.Context;import android.widget.*;import android.text.*;import org.mozilla.geckoview.*;import java.util.*;
public class MainActivity extends Activity {
 static GeckoRuntime runtime; GeckoSession session; GeckoView view; TextView status,addressText; EditText address; Button back,forward; Perms perms; LinearLayout head,portals,nav; boolean mediaFullScreen=false;
 static final String BOOK="https://catalogo-app-zm3w.onrender.com/c/libreria-ruiz", PRINT="https://volante-server.onrender.com/impresiones-ruiz";
 int navy=Color.rgb(20,65,119); int dp(int n){return (int)(n*getResources().getDisplayMetrics().density+.5f);} TextView text(String s,int size,int c){TextView t=new TextView(this);t.setText(s);t.setTextSize(size);t.setTextColor(c);return t;}
 @Override public void onCreate(Bundle state){super.onCreate(state);getWindow().setStatusBarColor(navy);getWindow().setNavigationBarColor(navy);
 LinearLayout root=new LinearLayout(this);root.setOrientation(1);root.setBackgroundColor(Color.WHITE);
 head=new LinearLayout(this);head.setGravity(Gravity.CENTER_VERTICAL);head.setPadding(dp(10),dp(5),dp(10),dp(5));head.setBackgroundColor(navy);
 TextView logo=text("R",28,Color.WHITE);logo.setTypeface(null,Typeface.BOLD);logo.setGravity(Gravity.CENTER);logo.setBackgroundColor(Color.rgb(31,112,172));head.addView(logo,new LinearLayout.LayoutParams(dp(42),dp(42)));
 LinearLayout brand=new LinearLayout(this);brand.setOrientation(1);brand.setPadding(dp(10),0,0,0);TextView title=text("RUIZ NAVEGADOR",16,Color.WHITE);title.setTypeface(null,Typeface.BOLD);brand.addView(title);brand.addView(text("Acceso directo a tus sitios",11,Color.rgb(220,232,245)));head.addView(brand,new LinearLayout.LayoutParams(0,-2,1));root.addView(head);
 portals=new LinearLayout(this);portals.setPadding(dp(6),dp(3),dp(6),dp(3));portals.setBackgroundColor(Color.rgb(239,244,249));Button lib=new Button(this);lib.setText("📚 Librería Ruiz");lib.setTextSize(12);portals.addView(lib,new LinearLayout.LayoutParams(0,dp(48),1));Button imp=new Button(this);imp.setText("🖨️ Impresiones Ruiz");imp.setTextSize(12);portals.addView(imp,new LinearLayout.LayoutParams(0,dp(48),1));root.addView(portals);
 nav=new LinearLayout(this);nav.setGravity(Gravity.CENTER_VERTICAL);nav.setPadding(dp(4),0,dp(4),0);back=new Button(this);back.setText("‹");nav.addView(back,new LinearLayout.LayoutParams(dp(42),dp(46)));address=new EditText(this);address.setSingleLine(true);address.setTextSize(13);address.setHint("Dirección del sitio");address.setInputType( android.text.InputType.TYPE_CLASS_TEXT|android.text.InputType.TYPE_TEXT_VARIATION_URI);nav.addView(address,new LinearLayout.LayoutParams(0,dp(44),1));Button go=new Button(this);go.setText("Ir");nav.addView(go,new LinearLayout.LayoutParams(dp(48),dp(46)));forward=new Button(this);forward.setText("›");nav.addView(forward,new LinearLayout.LayoutParams(dp(42),dp(46)));root.addView(nav);
 status=text("Preparando navegador…",11,Color.DKGRAY);status.setPadding(dp(10),dp(2),dp(10),dp(2));root.addView(status);view=new GeckoView(this);root.addView(view,new LinearLayout.LayoutParams(-1,0,1));setContentView(root);
 if(runtime==null)runtime=GeckoRuntime.create(this);session=new GeckoSession();session.setContentDelegate(new GeckoSession.ContentDelegate(){@Override public void onFullScreen(GeckoSession s,boolean fullScreen){runOnUiThread(new Runnable(){public void run(){mediaFullScreen=fullScreen;int visibility=fullScreen?View.GONE:View.VISIBLE;head.setVisibility(visibility);portals.setVisibility(visibility);nav.setVisibility(visibility);status.setVisibility(visibility);setSystemBarsHidden(fullScreen);}});}});perms=new Perms();session.setPermissionDelegate(perms);
 session.setNavigationDelegate(new GeckoSession.NavigationDelegate(){@Override public void onLocationChange(GeckoSession s,String url,java.util.List<GeckoSession.PermissionDelegate.ContentPermission> permissions,Boolean isReload){if(url!=null)address.setText(url);status.setText("Listo");}@Override public GeckoResult<String> onLoadError(GeckoSession s,String uri,WebRequestError e){runOnUiThread(new Runnable(){public void run(){status.setText("No se pudo cargar. Tocá Ir para reintentar.");}});return null;}});
 session.open(runtime);view.setSession(session);
 lib.setOnClickListener(new View.OnClickListener(){public void onClick(View v){load(BOOK);}});imp.setOnClickListener(new View.OnClickListener(){public void onClick(View v){load(PRINT);}});go.setOnClickListener(new View.OnClickListener(){public void onClick(View v){load(address.getText().toString());}});
 address.setOnEditorActionListener(new TextView.OnEditorActionListener(){public boolean onEditorAction(TextView v,int id,android.view.KeyEvent e){load(address.getText().toString());return true;}});back.setOnClickListener(new View.OnClickListener(){public void onClick(View v){session.goBack();}});forward.setOnClickListener(new View.OnClickListener(){public void onClick(View v){session.goForward();}});
 if(state!=null&&state.getString("url")!=null)load(state.getString("url"));else load(BOOK);
 }
 void setSystemBarsHidden(boolean hidden){if(Build.VERSION.SDK_INT>=30){android.view.WindowInsetsController c=getWindow().getInsetsController();if(c!=null){c.setSystemBarsBehavior(android.view.WindowInsetsController.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE);if(hidden)c.hide(android.view.WindowInsets.Type.systemBars());else c.show(android.view.WindowInsets.Type.systemBars());}}else{int flags=View.SYSTEM_UI_FLAG_LAYOUT_STABLE|View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN|View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION|View.SYSTEM_UI_FLAG_FULLSCREEN|View.SYSTEM_UI_FLAG_HIDE_NAVIGATION|View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY;getWindow().getDecorView().setSystemUiVisibility(hidden?flags:View.SYSTEM_UI_FLAG_VISIBLE);}}
 void load(String u){if(u==null||u.trim().length()==0)return;u=u.trim();if(!u.matches("(?i)^https?://.*"))u="https://"+u;address.setText(u);status.setText("Cargando sitio…");session.loadUri(u);}
 @Override protected void onSaveInstanceState(Bundle b){if(address!=null)b.putString("url",address.getText().toString());super.onSaveInstanceState(b);}
 @Override public void onBackPressed(){if(session!=null)session.goBack();else super.onBackPressed();}
 class Perms implements GeckoSession.PermissionDelegate {
  GeckoSession.PermissionDelegate.Callback androidCb;
  String[] requestedAndroid;
  final SharedPreferences saved=getSharedPreferences("ruiz_media_permissions",MODE_PRIVATE);
  String key(String prefix,String host){return prefix+host.toLowerCase(Locale.ROOT);}
  boolean isGranted(String permission){return Build.VERSION.SDK_INT<23||checkSelfPermission(permission)==PackageManager.PERMISSION_GRANTED;}
  @Override public void onAndroidPermissionsRequest(GeckoSession s,String[] requested,GeckoSession.PermissionDelegate.Callback cb){
   if(requested==null||requested.length==0){cb.grant();return;}
   ArrayList<String> missing=new ArrayList<>();
   for(String permission:requested){if(permission!=null&&!isGranted(permission))missing.add(permission);}
   if(missing.isEmpty()){cb.grant();return;}
   for(String permission:missing){if(saved.getBoolean(key("android-denied:",permission),false)){cb.reject();permissionSettingsToast();return;}}
   androidCb=cb;requestedAndroid=missing.toArray(new String[0]);
   runOnUiThread(new Runnable(){public void run(){requestPermissions(requestedAndroid,71);}});
  }
  boolean trusted(String u){
   try{android.net.Uri parsed=android.net.Uri.parse(u);String h=parsed.getHost();if(h==null||!"https".equalsIgnoreCase(parsed.getScheme()))return false;h=h.toLowerCase(Locale.ROOT);
    return h.equals("catalogo-app-zm3w.onrender.com")||h.equals("volante-server.onrender.com")||h.equals("embed.liveavatar.com");
   }catch(Exception e){return false;}
  }
  void permissionSettingsToast(){runOnUiThread(new Runnable(){public void run(){Toast.makeText(MainActivity.this,"Para usar Alma, habilitá micrófono/cámara en Ajustes de Android → Aplicaciones → Ruiz Navegador → Permisos.",Toast.LENGTH_LONG).show();}});}
  @Override public void onMediaPermissionRequest(GeckoSession s,String uri,GeckoSession.PermissionDelegate.MediaSource[] video,GeckoSession.PermissionDelegate.MediaSource[] audio,GeckoSession.PermissionDelegate.MediaCallback cb){
   if(!trusted(uri)){cb.reject();return;}
   final GeckoSession.PermissionDelegate.MediaSource[] v=video,a=audio;
   final boolean wantsVideo=v!=null&&v.length>0, wantsAudio=a!=null&&a.length>0;
   final String host=android.net.Uri.parse(uri).getHost().toLowerCase(Locale.ROOT);
   if(!wantsVideo&&!wantsAudio){cb.reject();return;}
   if((wantsAudio&&!isGranted(Manifest.permission.RECORD_AUDIO))||(wantsVideo&&!isGranted(Manifest.permission.CAMERA))){cb.reject();permissionSettingsToast();return;}
   final String permissionKind=(wantsAudio?"audio":"")+(wantsVideo?"-video":"");
   final String consentKey=key("site-allowed:"+permissionKind+":",host), deniedKey=key("site-denied:"+permissionKind+":",host);
   if(saved.getBoolean(deniedKey,false)){cb.reject();return;}
   Runnable grant=new Runnable(){public void run(){cb.grant(wantsVideo?v[0]:null,wantsAudio?a[0]:null);}};
   if(saved.getBoolean(consentKey,false)){grant.run();return;}
   runOnUiThread(new Runnable(){public void run(){
    String what=wantsAudio&&wantsVideo?"micrófono y cámara":(wantsAudio?"micrófono":"cámara");
    new AlertDialog.Builder(MainActivity.this).setTitle("Permiso para Alma")
     .setMessage("El sitio "+host+" solicita usar "+what+". Si lo permitís, Ruiz Navegador recordará tu elección para no volver a preguntarte aquí. Android también requiere su autorización del sistema la primera vez.")
     .setNegativeButton("No permitir",new DialogInterface.OnClickListener(){public void onClick(DialogInterface d,int w){saved.edit().putBoolean(deniedKey,true).apply();cb.reject();}})
     .setPositiveButton("Permitir",new DialogInterface.OnClickListener(){public void onClick(DialogInterface d,int w){saved.edit().putBoolean(consentKey,true).apply();grant.run();}}).setCancelable(false).show();
   }});
  }
 }
 @Override public void onRequestPermissionsResult(int c,String[] p,int[] g){super.onRequestPermissionsResult(c,p,g);if(c==71&&perms!=null&&perms.androidCb!=null){GeckoSession.PermissionDelegate.Callback cb=perms.androidCb;perms.androidCb=null;boolean ok=g!=null&&g.length>0;if(g!=null)for(int x:g)if(x!=PackageManager.PERMISSION_GRANTED)ok=false;if(ok)cb.grant();else{if(perms.requestedAndroid!=null)for(String permission:perms.requestedAndroid)perms.saved.edit().putBoolean("android-denied:"+permission,true).apply();cb.reject();}}}
 @Override protected void onDestroy(){if(view!=null)view.releaseSession();if(session!=null){session.close();session=null;}super.onDestroy();}
}
